import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/header';
import Section from './components/section';
import Footer from './components/footer';

function App() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route path="/" exact>
          <Section title="Sección 1" description="Esta es la sección 1." />
        </Route>
        <Route path="/section2">
          <Section title="Sección 2" description="Esta es la sección 2." />
        </Route>
        <Route path="/section3">
          <Section title="Sección 3" description="Esta es la sección 3." />
        </Route>
      </Switch>
      <Footer />
    </Router>
  );
}

export default App;
