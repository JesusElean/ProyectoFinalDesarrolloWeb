import { Link } from 'react-router-dom';

function Menu() {
  return (
    <nav>
      <ul>
        <li><Link to="/">Sección 1</Link></li>
        <li><Link to="/section2">Sección 2</Link></li>
        <li><Link to="/section3">Sección 3</Link></li>
      </ul>
    </nav>
  );
}

export default Menu;
