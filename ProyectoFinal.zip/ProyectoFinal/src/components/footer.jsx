function Footer() {
  return (
    <footer>
      <p>© 2024 Mi Sitio Web. Todos los derechos reservados.</p>
    </footer>
  );
}

export default Footer;
