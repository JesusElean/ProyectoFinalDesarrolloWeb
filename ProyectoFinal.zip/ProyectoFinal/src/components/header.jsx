import React from 'react';
import Menu from './Menu';

function Header() {
  return (
    <header>
      <h1>Mi Sitio Web con React</h1>
      <Menu />
    </header>
  );
}

export default Header;
