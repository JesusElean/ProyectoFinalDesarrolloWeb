import React, { useState } from 'react';

function Section({ title, description }) {
  const [feedback, setFeedback] = useState('');
  const handleSubmit = (event) => {
    event.preventDefault();
    alert(`Feedback recibido: ${feedback}`);
  };

  return (
    <section>
      <h2>{title}</h2>
      <p>{description}</p>
      <form onSubmit={handleSubmit}>
        <label>
          Feedback:
          <input
            type="text"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
        </label>
        <button type="submit">Enviar</button>
      </form>
    </section>
  );
}

export default Section;
